var AWS = require("aws-sdk");
var https = require('https');
var mysql = require('mysql');
var ses = new AWS.SES({region: 'ap-south-1'});
//var connection;

exports.handler = (event, context, callback) => {
    if (!event.hasOwnProperty("tfa_checker")) {
        callback("Valid parameter not found");
        return;
    }
    
    const now = new Date();
    now.setTime(now.getTime() + (5 * 60 * 60 * 1000) + (30 * 60 * 1000));
    
    var emailIDArr =[
                    "ruturajraut2000@gmail.com",
                    //"gautam@claypot.in",
                    //"chauhan@claypot.in",
                    //"tech-assist@claypot.in",
                    //"yogesh@claypot.in"
                        
                    ];
    
    const connection = mysql.createConnection({
        host: "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
        user: "claypot_db_user",
        password: "claypot_db_user_password",
        database: "claypot_db",
        multipleStatements: true
    });

    connection.connect(err => {
        if (err) {
            console.error('Error conecting to my sql', err);
            return;
        }
    });

    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    let day = now.getDate();
    let hour = now.getHours();
    //let min = now.getMinutes().toString().padStart(2, '0');
    let emailerrorlist = [];
    let teleerrorlist = [];

    if (month < 10) { month = "0" + month }
    if (day < 10) { day = "0" + day }
    if (hour < 10) { hour = "0" + hour }

    const dateTimeString = year + "-" + month + "-" + day + " " + hour;
    //const dateString = year + "-" + month + "-" + day;


    console.log("Date time string:", dateTimeString);
    
    //var isScheduledOnTime = false;
    //var isScheduledOffTime = false;
    
    var query = `select * FROM claypot_db.quantum_tfa where tfa_id= 'roofTFASolusSide' order by id desc limit 1;`;
    query += `select * FROM claypot_db.quantum_tfa where tfa_id= 'roofTFABayerSide' order by id desc limit 1;`;
    
    // var query = `select * FROM claypot_db.quantum_tfa where tfa_id= 'roofTFASolusSide';`;
    // query += `select * FROM claypot_db.quantum_tfa where tfa_id= 'roofTFABayerSide';`;

    connection.query(query, (err, result) => {
        if (err) {
            console.error('Error executing query', err);
            return;
        } else {
            
            var recordHour;
            var recordMinute;
         //console.log("Result",result)
                result.forEach(row => {
                    //console.log("Row -------",row)
                    console.log("Row===",row[0].run_status)
                    var tfa =  row[0].run_status;
                    var tfa_name = row[0].tfa_id;
                    console.log("tfa_name",tfa_name)
                   // console.log("Run Status",typeof(row.run_status),row.run_status)
                    const recordDt = new Date(row[0].dt);
                    const dbDate = recordDt.getDate()
                    console.log("dbDate",dbDate)
                    recordHour = recordDt.getUTCHours().toString().padStart(2, '0');
                    recordMinute = recordDt.getUTCMinutes().toString().padStart(2, '0');
                    
                    console.log(`${tfa_name} record time: ${recordHour}:${recordMinute}`);
                
                //tfa on    
                if((recordHour >= 7 && recordHour < 10) && (tfa == 0) && (dbDate == day)){
                   
                    emailerrorlist.push(`<br> Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .\n\n`);
                    
                }
                else if( ((recordHour == 10 && recordMinute>30) || (recordHour > 10 && recordHour < 14) || (recordHour == 14 && recordMinute<30)) && (tfa === 0) && (dbDate == day)){
                    
                    emailerrorlist.push(`<br> Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .\n\n`);
                    
                }
                else if((recordHour >= 15 && recordHour < 17) && (tfa == 0) && (dbDate == day)){
                  
                    emailerrorlist.push(`<br> Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .\n\n`);
                }
                else if(((recordHour == 17 && recordMinute>30) || (recordHour > 17 && recordHour < 19) || (recordHour == 19 && recordMinute<30)) && (tfa == 0) && (dbDate == day)){
                    
                    emailerrorlist.push(`<br> Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n Octopus has detected that ${tfa_name} is OFF when it is supposed to be ON at ${recordHour}:${recordMinute} .\n\n`);
                    
                }
                
                //tfa off
                // else if(((recordHour >= 10 && recordHour < 11) || (recordHour == 10 && recordMinute <= 30)) && (tfa == 1) && (dbDate == day)){
                   
                //     emailerrorlist.push(`<br> 1Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .</b><br>`);
                //     teleerrorlist.push(`\n 1Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .\n\n`);
                // }
                else if(((recordHour === 10 && recordMinute <= 30) || (recordHour === 10)) && (tfa === 1) && (dbDate === day)){
                    emailerrorlist.push(`<br> 1Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n 1Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .\n\n`);
                }
                // ((recordHour === 14 && recordMinute >= 30) || (recordHour === 15)) && (tfa === 1) && (dbDate === day)
                else if((recordHour == 14 && recordMinute >= 30) || ((recordHour < 15) && (recordHour > 14)) && (tfa == 1) && (dbDate == day) ){
                    
                    emailerrorlist.push(`<br> 2Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n 2Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .\n\n`);
                    
                }
                // ((recordHour === 17 && recordMinute <= 30) || (recordHour === 17)) && (tfa === 1) && (dbDate === day)
                else if(((recordHour == 17) || (recordHour == 17 && recordMinute <= 30)) && (tfa == 1) && (dbDate == day)){
                    
                    emailerrorlist.push(`<br>3 Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n 3Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .\n\n`);
                }
                // ((recordHour === 19 && recordMinute >= 30)) && (tfa === 1) && (dbDate === day)
                else if(((recordHour == 19 && recordMinute >= 30) || (recordHour>19)) && (tfa == 1) ){
                    
                    emailerrorlist.push(`<br> 4Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .</b><br>`);
                    teleerrorlist.push(`\n 4Octopus has detected that ${tfa_name} is ON when it is supposed to be OFF at ${recordHour}:${recordMinute} .\n\n`);
                    
                }
                
                });
            
                console.log("email error list +++++",emailerrorlist);
                console.log("Tele error list +++++",teleerrorlist);

            if (emailerrorlist.length > 0) {
                sendMail(emailIDArr, "Problem Detected with TFA data:", emailerrorlist, callback);
            } else {
                console.log("No error in mail sending.");
            }

            if (teleerrorlist.length > 0) {
                sendPhotoToTelegram(teleerrorlist, callback);
            } else {
                noErrorMsgToTelegram(callback);
            }

            connection.end();
        }
    });
}

async function sendPhotoToTelegram(teleerrorlist,callback) {
    // Construct the URL for the Telegram Bot API endpoint
    console.log('in telegram function')
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString +=`?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
   
    var teleerrorMessage = `Problem Detected with TFA are as follows:\n\n${teleerrorlist.map(error => `-${error}`).join('\n\n')}`;
    var telecontent =  teleerrorMessage.split('<br>').join('')
    
   // console.log("Error msg ----+",teleerrorMessage)
    
    console.log('********',telecontent)
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;
    //console.log("URLString", URLString)

  
      // Make the HTTP request to send the photo
          // Make the HTTP request to send the photo
    const request = new https.get(URLString, (response) => {
        //console.log('in response');
        console.log('Telegram API response:', response.statusCode);
        callback(null,`Telegram response code ${response.statusCode}`);
       
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);   // error.message
        callback(error.message);   // same
        
    });
    
    //request.end();

    
}

async function noErrorMsgToTelegram(callback) {
    // Construct the URL for the Telegram Bot API endpoint
    //console.log('in telegram function');
    var photoUrl = `https://www.octopus-automation.com/apps/eqi/images/telegram/air-quality-problem.png`;
    var URLString = 'https://api.telegram.org/bot5854610426:AAF2F6aBmlNXnEUoG-Lzub7VR19UlNY21JU/sendPhoto';

    URLString += `?chat_id=-1001640441317`; // test channel
    URLString += `&photo=${photoUrl}`;
    var telecontent =  `<b>TFA data Checked.</b>\n\n`;
    telecontent += `No change Detected `;
    console.log('********',telecontent);
    
    // Append the error message to the URL string
    URLString += `&caption=${encodeURIComponent(telecontent)}`;
    URLString += `&parse_mode=html`;

  
    // Make the HTTP request to send the photo
    const request = new https.get(URLString, (response) => {
        //console.log('in response')
        console.log('Telegram API response:', response.statusCode);
        callback(null,`Telegram response code ${response.statusCode}`)
    }).on('error', (error) => {
        console.error('Telegram API call Error:', error.message);
        callback(error.message)
    });
    
}

async function mailcontent(errorlist,ahuName) {
    let mailContent = `<html>`;
    mailContent += `<body>`;
    mailContent += `<h2 style="color:darkgreen">TFA data </h2>`;
    mailContent += `<table id="octopus-table" border=1 bordercolor="#fff" cellspacing=0 cellpadding=15 style="border-radius:15px">`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th colspan=3>TFA Alert</th>`;
    mailContent += `</tr>`;
    mailContent += `<tr style="background-color:black;color:#fff" class='tableheader'>`;
    mailContent += `<th style="text-align:center;background-color:green;color:#fff">Problem Detected with TFA</th>`;
    mailContent += `</tr>`;

    // Append dynamic table rows based on errorlist
    errorlist.forEach(error => {
        mailContent += `<tr>`;
        mailContent += `<td style="background-color:orange;color:#fff"><b>${error}</b></td>`;
        mailContent += `</tr>`;
    });


    // Close HTML body and table tags
    mailContent += `</table>`;
    mailContent += `</body>`;
    mailContent += `</html>`;

    return mailContent;
}


async function sendMail(emailIdArr,subject,errorlist,callback)
    {
        console.log(emailIdArr);
        // console.log(data);
        var msg = await mailcontent(errorlist); // Call mailcontent function here to get the mail message
        //console.log("---msg---",msg);
        const emailParams = {
           
            Destination: {
              //ToAddresses: ["gautam@claypot.in","yogesh@claypot.in"],
              ToAddresses: emailIdArr,
            },
            Message: {
              Body: {
                Html: { Data: msg },
              },
              Subject: { Data: subject },
            },
            Source: "octopus-alerts@octopusio.io",
        };
        console.log('after mail content');
          
        try {
            let key = await ses.sendEmail(emailParams).promise();
            console.log("MAIL SENT SUCCESSFULLY!!");
            callback(null,true);
        } catch (e) {
            //console.log("FAILURE IN SENDING MAIL!!", e);
            callback("Failure in sending mail" + e);
          }  
        return;
}